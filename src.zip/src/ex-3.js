console.log('What do you call a bear with no teeth?\nA gummy bear!');
