import { question } from 'readline-sync';

const input = question('무슨무슨 값을 입력하세요...');

console.log(input);
